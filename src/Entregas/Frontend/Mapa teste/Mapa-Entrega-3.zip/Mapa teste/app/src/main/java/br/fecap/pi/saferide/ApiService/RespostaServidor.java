package br.fecap.pi.saferide.ApiService;

public class RespostaServidor {
    private String message;
    private int IDUsuario;

    // Getters
    public String getMessage() { return message; }
    public int getId() { return IDUsuario; }
}
    