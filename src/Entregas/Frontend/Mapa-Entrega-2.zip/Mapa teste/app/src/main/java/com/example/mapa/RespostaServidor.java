package com.example.mapa;

public class RespostaServidor {
    private String message;
    private int id;

    // Getters
    public String getMessage() { return message; }
    public int getId() { return id; }
}
    